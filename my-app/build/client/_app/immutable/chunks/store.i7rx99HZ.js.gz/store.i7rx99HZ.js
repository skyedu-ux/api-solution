import{w as a}from"./index.BPQfFJo-.js";const t=a(),s=a(!1);export{t as d,s as g};
