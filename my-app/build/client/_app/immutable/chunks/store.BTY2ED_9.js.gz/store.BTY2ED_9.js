import{w as a}from"./index.CvdT8md8.js";const t=a(),s=a(!1);export{t as d,s as g};
