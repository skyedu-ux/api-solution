import{w as a}from"./index.C-J9etjc.js";const t=a(),s=a(!1);export{t as d,s as g};
