const s="https://images.pexels.com/photos/7682340/pexels-photo-7682340.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",o=2097152,t={DEFAULT_LIMIT:10,DEFAULT_PAGE:1};export{s as B,o as M,t as P};
