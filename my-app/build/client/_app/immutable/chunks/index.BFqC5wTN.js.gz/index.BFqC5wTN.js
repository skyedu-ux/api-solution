let e=!1;function a(){e=!0}export{a as e,e as l};
