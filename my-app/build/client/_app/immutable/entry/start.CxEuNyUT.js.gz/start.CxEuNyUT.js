import{a as t}from"../chunks/entry.C54j5Ft0.js";export{t as start};
