import{a as t}from"../chunks/entry.CC_BJODY.js";export{t as start};
