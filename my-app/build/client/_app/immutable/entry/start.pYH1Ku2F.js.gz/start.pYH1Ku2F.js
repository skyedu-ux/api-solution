import{a as t}from"../chunks/entry.CdBhVsaT.js";export{t as start};
