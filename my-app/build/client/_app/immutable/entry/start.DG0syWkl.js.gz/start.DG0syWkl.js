import{a as t}from"../chunks/entry.5HYBzXlr.js";export{t as start};
