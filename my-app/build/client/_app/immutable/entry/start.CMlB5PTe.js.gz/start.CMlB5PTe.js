import{a as t}from"../chunks/entry.DqrsjDor.js";export{t as start};
