import{a as t}from"../chunks/entry.lVKKxEUb.js";export{t as start};
