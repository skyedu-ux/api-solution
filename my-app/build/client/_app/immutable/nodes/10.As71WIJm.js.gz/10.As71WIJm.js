import"../chunks/disclose-version.Bg9kRutz.js";import"../chunks/legacy.CtaTdtmd.js";import{J as t}from"../chunks/JobList.D8BLLM2Q.js";function r(o){t(o,{})}export{r as component};
